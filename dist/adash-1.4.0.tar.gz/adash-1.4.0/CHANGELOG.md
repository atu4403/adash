# Changelog
All notable changes to this project will be documented in this file.

<a name="v1.3.0"></a>
## [v1.3.0](/compare/v1.1.0...v1.3.0)

> 2022-01-04

### Features

* add file_util.cat

<a name="v1.1.0"></a>
## [v1.1.0](/compare/v1.0.0...v1.1.0)

> 2022-01-01

### Code Refactoring

* ファイル名の変更

### Features

* json_read, json_writeを追加

<a name="v1.0.0"></a>
## [v1.0.0](/compare/v0.2.0...v1.0.0)

> 2021-12-26

### Features

* to_md5, to_sha256を追加
